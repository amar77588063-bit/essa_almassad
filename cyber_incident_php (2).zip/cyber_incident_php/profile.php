<?php
require_once 'includes/auth.php';
require_login();

$stmt = $pdo->prepare('SELECT COUNT(*) FROM incidents WHERE created_by = ?');
$stmt->execute([$_SESSION['user']['id']]);
$myIncidents = (int)$stmt->fetchColumn();

$pageTitle = 'حسابي';
include 'includes/header.php';
?>
<section class="card">
    <h1>الملف الشخصي</h1>
    <div class="details-grid">
        <div><span>اسم المستخدم</span><strong><?= e($_SESSION['user']['username']) ?></strong></div>
        <div><span>البريد</span><strong><?= e($_SESSION['user']['email']) ?></strong></div>
        <div><span>الدور</span><strong><?= e(role_label()) ?></strong></div>
        <div><span>الحوادث التي أبلغت عنها</span><strong><?= $myIncidents ?></strong></div>
    </div>

    <h3>صلاحيات حسابك</h3>
    <?php if (is_employee()): ?>
        <p>إنشاء بلاغات، مشاهدة بلاغاتك فقط، تعديل البلاغ المفتوح، وإضافة التعليقات.</p>
    <?php elseif (is_analyst()): ?>
        <p>مشاهدة جميع الحوادث، تعديلها، تغيير حالتها وخطورتها، وإضافة التعليقات. لا يمكنه حذف الحوادث أو إدارة المستخدمين.</p>
    <?php else: ?>
        <p>جميع صلاحيات المحلل، بالإضافة إلى حذف الحوادث وإضافة المستخدمين وتغيير أدوارهم.</p>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>
