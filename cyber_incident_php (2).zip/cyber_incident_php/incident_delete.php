<?php
require_once 'includes/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

verify_csrf();
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if (!$id) exit('Invalid incident ID.');

$stmt = $pdo->prepare('SELECT id FROM incidents WHERE id = ?');
$stmt->execute([$id]);
if (!$stmt->fetch()) {
    http_response_code(404);
    exit('Incident not found.');
}

$stmt = $pdo->prepare('DELETE FROM incidents WHERE id = ?');
$stmt->execute([$id]);
header('Location: incidents.php');
exit;
