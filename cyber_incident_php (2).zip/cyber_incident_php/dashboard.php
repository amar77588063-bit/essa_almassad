<?php
require_once 'includes/auth.php';
require_login();

$where = '';
$params = [];
if (is_employee()) {
    $where = ' WHERE created_by = ?';
    $params[] = $_SESSION['user']['id'];
}

function count_incidents(PDO $pdo, string $where, array $params, string $extra = ''): int {
    $sql = 'SELECT COUNT(*) FROM incidents' . $where;
    if ($extra !== '') {
        $sql .= ($where === '' ? ' WHERE ' : ' AND ') . $extra;
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

$total = count_incidents($pdo, $where, $params);
$open = count_incidents($pdo, $where, $params, "status='OPEN'");
$investigating = count_incidents($pdo, $where, $params, "status='INVESTIGATING'");
$resolved = count_incidents($pdo, $where, $params, "status IN ('RESOLVED','CLOSED')");
$critical = count_incidents($pdo, $where, $params, "severity='CRITICAL'");

$sql = "
    SELECT i.id, i.title, i.severity, i.status, i.created_at, i.created_by, u.username,
           (SELECT COUNT(*) FROM incidents seq WHERE seq.id <= i.id) AS display_no
    FROM incidents i
    JOIN users u ON u.id = i.created_by
";
$recentParams = [];
if (is_employee()) {
    $sql .= ' WHERE i.created_by = ?';
    $recentParams[] = $_SESSION['user']['id'];
}
$sql .= ' ORDER BY i.created_at DESC LIMIT 5';
$stmt = $pdo->prepare($sql);
$stmt->execute($recentParams);
$recent = $stmt->fetchAll();

$pageTitle = 'لوحة التحكم';
include 'includes/header.php';
?>
<div class="page-title">
    <div>
        <h1>لوحة التحكم</h1>
        <p>مرحبًا <?= e($_SESSION['user']['username']) ?> — صلاحيتك: <strong><?= e(role_label()) ?></strong>.</p>
        <?php if (is_employee()): ?>
            <p class="muted">الإحصائيات هنا تخص البلاغات التي أنشأتها أنت فقط.</p>
        <?php else: ?>
            <p class="muted">الإحصائيات هنا تشمل جميع الحوادث في النظام.</p>
        <?php endif; ?>
    </div>
    <a class="btn" href="incident_add.php">+ إضافة حادث</a>
</div>

<div class="stats">
    <div class="stat"><strong><?= $total ?></strong><span>إجمالي الحوادث</span></div>
    <div class="stat"><strong><?= $open ?></strong><span>مفتوحة</span></div>
    <div class="stat"><strong><?= $investigating ?></strong><span>قيد التحقيق</span></div>
    <div class="stat"><strong><?= $resolved ?></strong><span>تم حلها / أغلقت</span></div>
    <div class="stat danger"><strong><?= $critical ?></strong><span>حرجة</span></div>
</div>

<section class="card">
    <div class="section-head">
        <h2><?= is_employee() ? 'أحدث بلاغاتي' : 'أحدث الحوادث' ?></h2>
        <a href="incidents.php">عرض الكل</a>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>#</th><th>العنوان</th><th>الخطورة</th><th>الحالة</th><th>المبلّغ</th><th>التاريخ</th></tr></thead>
            <tbody>
            <?php foreach ($recent as $item): ?>
                <tr>
                    <td><?= (int)$item['display_no'] ?></td>
                    <td><a href="incident_view.php?id=<?= (int)$item['id'] ?>"><?= e($item['title']) ?></a></td>
                    <td><?= e(severity_label($item['severity'])) ?></td>
                    <td><?= e(status_label($item['status'])) ?></td>
                    <td><?= e($item['username']) ?></td>
                    <td><?= e($item['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$recent): ?><tr><td colspan="6">لا توجد حوادث حتى الآن.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
