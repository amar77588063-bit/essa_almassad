<?php
require_once 'includes/auth.php';
require_login();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) exit('Invalid incident ID.');

$stmt = $pdo->prepare("
    SELECT i.*, u.username,
           (SELECT COUNT(*) FROM incidents seq WHERE seq.id <= i.id) AS display_no
    FROM incidents i
    JOIN users u ON u.id = i.created_by
    WHERE i.id = ?
");
$stmt->execute([$id]);
$incident = $stmt->fetch();

if (!$incident) {
    http_response_code(404);
    exit('Incident not found.');
}

if (!can_view_incident($incident)) {
    http_response_code(403);
    exit('ليس لديك صلاحية مشاهدة هذا الحادث.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    verify_csrf();
    $comment = trim($_POST['comment'] ?? '');
    if ($comment !== '') {
        $stmt = $pdo->prepare('INSERT INTO comments (incident_id, user_id, comment) VALUES (?, ?, ?)');
        $stmt->execute([$id, $_SESSION['user']['id'], $comment]);
    }
    header("Location: incident_view.php?id=$id");
    exit;
}

$stmt = $pdo->prepare("
    SELECT c.comment, c.created_at, u.username
    FROM comments c
    JOIN users u ON u.id = c.user_id
    WHERE c.incident_id = ?
    ORDER BY c.created_at ASC
");
$stmt->execute([$id]);
$comments = $stmt->fetchAll();

$pageTitle = 'تفاصيل الحادث';
include 'includes/header.php';
?>
<section class="card">
    <div class="section-head">
        <h1>الحادث #<?= (int)$incident['display_no'] ?></h1>
        <div class="actions">
            <?php if (can_edit_incident($incident)): ?>
                <a class="btn secondary" href="incident_edit.php?id=<?= (int)$incident['id'] ?>">تعديل</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="details-grid">
        <div><span>العنوان</span><strong><?= e($incident['title']) ?></strong></div>
        <div><span>التصنيف</span><strong><?= e(category_label($incident['category'])) ?></strong></div>
        <div><span>الخطورة</span><strong><?= e(severity_label($incident['severity'])) ?></strong></div>
        <div><span>الحالة</span><strong><?= e(status_label($incident['status'])) ?></strong></div>
        <div><span>المبلّغ</span><strong><?= e($incident['username']) ?></strong></div>
        <div><span>تاريخ الإنشاء</span><strong><?= e($incident['created_at']) ?></strong></div>
    </div>

    <?php if (is_employee() && $incident['status'] !== 'OPEN'): ?>
        <div class="alert info">هذا البلاغ دخل مرحلة المعالجة، لذلك لا يستطيع الموظف تعديله الآن.</div>
    <?php endif; ?>

    <h3>الوصف</h3>
    <p><?= nl2br(e($incident['description'])) ?></p>
</section>

<section class="card">
    <h2>التعليقات</h2>
    <?php foreach ($comments as $comment): ?>
        <div class="comment">
            <strong><?= e($comment['username']) ?></strong>
            <small><?= e($comment['created_at']) ?></small>
            <p><?= nl2br(e($comment['comment'])) ?></p>
        </div>
    <?php endforeach; ?>
    <?php if (!$comments): ?><p class="muted">لا توجد تعليقات بعد.</p><?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <label>إضافة تعليق</label>
        <textarea name="comment" rows="4" required></textarea>
        <button type="submit">إضافة التعليق</button>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
