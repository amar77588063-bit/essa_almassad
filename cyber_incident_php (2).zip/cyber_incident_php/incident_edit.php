<?php
require_once 'includes/auth.php';
require_login();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) exit('Invalid incident ID.');

$stmt = $pdo->prepare('SELECT * FROM incidents WHERE id = ?');
$stmt->execute([$id]);
$incident = $stmt->fetch();

if (!$incident) {
    http_response_code(404);
    exit('Incident not found.');
}

if (!can_edit_incident($incident)) {
    http_response_code(403);
    exit('ليس لديك صلاحية تعديل هذا الحادث.');
}

$categories = ['PHISHING','MALWARE','UNAUTHORIZED_ACCESS','DATA_LEAKAGE','ACCOUNT_COMPROMISE','OTHER'];
$severities = ['LOW','MEDIUM','HIGH','CRITICAL'];
$statuses = ['OPEN','INVESTIGATING','RESOLVED','CLOSED'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = $_POST['category'] ?? '';

    if ($title === '' || $description === '' || !in_array($category, $categories, true)) {
        $error = 'يرجى إدخال بيانات صحيحة.';
    } else {
        if (is_employee()) {
            $stmt = $pdo->prepare("
                UPDATE incidents
                SET title = ?, description = ?, category = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$title, $description, $category, $id]);
        } else {
            $severity = $_POST['severity'] ?? '';
            $status = $_POST['status'] ?? '';
            if (!in_array($severity, $severities, true) || !in_array($status, $statuses, true)) {
                $error = 'الخطورة أو الحالة غير صحيحة.';
            } else {
                $stmt = $pdo->prepare("
                    UPDATE incidents
                    SET title = ?, description = ?, category = ?, severity = ?, status = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$title, $description, $category, $severity, $status, $id]);
            }
        }

        if ($error === '') {
            header("Location: incident_view.php?id=$id");
            exit;
        }
    }
}

$pageTitle = 'تعديل الحادث';
include 'includes/header.php';
?>
<section class="card form-card">
    <h1>تعديل الحادث #<?= (int)$incident['id'] ?></h1>

    <?php if (is_employee()): ?>
        <div class="alert info">كموظف يمكنك تعديل بيانات البلاغ وهو مفتوح، لكن تغيير الحالة والخطورة من صلاحية المحلل أو المسؤول.</div>
    <?php endif; ?>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

        <label>العنوان</label>
        <input type="text" name="title" value="<?= e($incident['title']) ?>" required>

        <label>التصنيف</label>
        <select name="category">
            <?php foreach ($categories as $value): ?>
                <option value="<?= e($value) ?>" <?= $incident['category'] === $value ? 'selected' : '' ?>><?= e($value) ?></option>
            <?php endforeach; ?>
        </select>

        <?php if (!is_employee()): ?>
            <label>الخطورة</label>
            <select name="severity">
                <?php foreach ($severities as $value): ?>
                    <option value="<?= e($value) ?>" <?= $incident['severity'] === $value ? 'selected' : '' ?>><?= e($value) ?></option>
                <?php endforeach; ?>
            </select>

            <label>الحالة</label>
            <select name="status">
                <?php foreach ($statuses as $value): ?>
                    <option value="<?= e($value) ?>" <?= $incident['status'] === $value ? 'selected' : '' ?>><?= e($value) ?></option>
                <?php endforeach; ?>
            </select>
        <?php endif; ?>

        <label>الوصف</label>
        <textarea name="description" rows="7" required><?= e($incident['description']) ?></textarea>
        <button type="submit">حفظ التعديلات</button>
    </form>

    <?php if (can_delete_incident($incident)): ?>
        <form class="delete-form" method="post" action="incident_delete.php" onsubmit="return confirmDelete();">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= (int)$incident['id'] ?>">
            <button class="danger-btn" type="submit">حذف الحادث</button>
        </form>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>
