<?php
require_once 'includes/auth.php';
require_login();

$error = '';

$categories = [
    'PHISHING' => 'تصيد إلكتروني',
    'MALWARE' => 'برمجيات خبيثة',
    'UNAUTHORIZED_ACCESS' => 'دخول غير مصرح',
    'DATA_LEAKAGE' => 'تسريب بيانات',
    'ACCOUNT_COMPROMISE' => 'اختراق حساب',
    'OTHER' => 'أخرى'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = $_POST['category'] ?? '';
    $severity = $_POST['severity'] ?? 'LOW';

    if ($title === '' || $description === '' || !isset($categories[$category])) {
        $error = 'يرجى تعبئة جميع الحقول المطلوبة.';
    } elseif (!in_array($severity, ['LOW','MEDIUM','HIGH','CRITICAL'], true)) {
        $error = 'درجة الخطورة غير صحيحة.';
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO incidents (title, description, category, severity, status, created_by)
            VALUES (?, ?, ?, ?, 'OPEN', ?)
        ");
        $stmt->execute([$title, $description, $category, $severity, $_SESSION['user']['id']]);

        $id = (int)$pdo->lastInsertId();
        header("Location: incident_view.php?id=$id");
        exit;
    }
}

$pageTitle = 'إضافة حادث';
include 'includes/header.php';
?>
<section class="card form-card">
    <h1>إضافة حادث جديد</h1>

    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

        <label>عنوان الحادث</label>
        <input type="text" name="title" required>

        <label>التصنيف</label>
        <select name="category" required>
            <?php foreach ($categories as $key => $label): ?>
                <option value="<?= e($key) ?>"><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>

        <label>درجة الخطورة</label>
        <select name="severity">
            <option value="LOW">منخفض</option>
            <option value="MEDIUM">متوسط</option>
            <option value="HIGH">مرتفع</option>
            <option value="CRITICAL">حرج</option>
        </select>

        <label>الوصف</label>
        <textarea name="description" rows="7" required></textarea>

        <button type="submit">حفظ الحادث</button>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
