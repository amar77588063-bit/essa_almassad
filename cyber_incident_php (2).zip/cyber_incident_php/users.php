<?php
require_once 'includes/auth.php';
require_admin();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? 'EMPLOYEE';

        if (strlen($username) < 3 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
            $error = 'تحقق من اسم المستخدم والبريد وكلمة المرور (6 أحرف على الأقل).';
        } elseif (!in_array($role, ['EMPLOYEE','ANALYST','ADMIN'], true)) {
            $error = 'الدور غير صحيح.';
        } else {
            try {
                $stmt = $pdo->prepare('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)');
                $stmt->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $role]);
                $success = 'تم إنشاء المستخدم وتشفير كلمة المرور تلقائيًا.';
            } catch (PDOException $e) {
                $error = 'اسم المستخدم أو البريد مستخدم مسبقًا.';
            }
        }
    }

    if ($action === 'role') {
        $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
        $role = $_POST['role'] ?? '';

        if (!$userId || !in_array($role, ['EMPLOYEE','ANALYST','ADMIN'], true)) {
            $error = 'بيانات الدور غير صحيحة.';
        } elseif ((int)$userId === (int)$_SESSION['user']['id']) {
            $error = 'لا يمكنك تغيير دور حسابك الحالي من هذه الصفحة.';
        } else {
            $stmt = $pdo->prepare('UPDATE users SET role = ? WHERE id = ?');
            $stmt->execute([$role, $userId]);
            $success = 'تم تحديث صلاحية المستخدم.';
        }
    }
}

$users = $pdo->query('SELECT id, username, email, role, created_at FROM users ORDER BY id ASC')->fetchAll();
$pageTitle = 'إدارة المستخدمين';
include 'includes/header.php';
?>
<div class="page-title">
    <div>
        <h1>إدارة المستخدمين</h1>
        <p>هذه الصفحة متاحة لمسؤول النظام فقط.</p>
    </div>
</div>

<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>

<section class="card form-card">
    <h2>إضافة مستخدم</h2>
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="add">

        <label>اسم المستخدم</label>
        <input type="text" name="username" required>
        <label>البريد الإلكتروني</label>
        <input type="email" name="email" required>
        <label>كلمة المرور</label>
        <input type="password" name="password" minlength="6" required>
        <label>الدور</label>
        <select name="role">
            <option value="EMPLOYEE">موظف</option>
            <option value="ANALYST">محلل أمني</option>
            <option value="ADMIN">مسؤول النظام</option>
        </select>
        <button type="submit">إضافة المستخدم</button>
    </form>
</section>

<section class="card table-wrap">
    <h2>المستخدمون</h2>
    <table>
        <thead><tr><th>#</th><th>اسم المستخدم</th><th>البريد</th><th>الدور</th><th>تغيير الصلاحية</th></tr></thead>
        <tbody>
        <?php $displayNo = 1; ?>
        <?php foreach ($users as $item): ?>
            <tr>
                <td><?= $displayNo++ ?></td>
                <td><?= e($item['username']) ?><?= (int)$item['id'] === (int)$_SESSION['user']['id'] ? ' (أنت)' : '' ?></td>
                <td><?= e($item['email']) ?></td>
                <td><?= e(role_label($item['role'])) ?></td>
                <td>
                    <?php if ((int)$item['id'] !== (int)$_SESSION['user']['id']): ?>
                        <form class="inline-form" method="post">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="role">
                            <input type="hidden" name="user_id" value="<?= (int)$item['id'] ?>">
                            <select name="role">
                                <?php foreach (['EMPLOYEE'=>'موظف','ANALYST'=>'محلل أمني','ADMIN'=>'مسؤول النظام'] as $key=>$label): ?>
                                    <option value="<?= $key ?>" <?= $item['role'] === $key ? 'selected' : '' ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit">حفظ</button>
                        </form>
                    <?php else: ?>
                        <span class="muted">الحساب الحالي</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>
<?php include 'includes/footer.php'; ?>
