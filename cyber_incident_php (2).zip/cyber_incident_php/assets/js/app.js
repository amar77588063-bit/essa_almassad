function confirmDelete() {
    return confirm('هل أنت متأكد من حذف هذا الحادث؟ لا يمكن التراجع عن العملية.');
}
