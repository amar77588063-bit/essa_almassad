<?php
require_once 'config.php';

if (!empty($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare(
        'SELECT id, username, email, password, role FROM users WHERE username = ? LIMIT 1'
    );
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        unset($user['password']);
        session_regenerate_id(true);
        $_SESSION['user'] = $user;

        header('Location: dashboard.php');
        exit;
    }

    $error = 'اسم المستخدم أو كلمة المرور غير صحيحة.';
}

$pageTitle = 'تسجيل الدخول';
include 'includes/header.php';
?>
<section class="auth-card">
    <h1>تسجيل الدخول</h1>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

        <label>اسم المستخدم</label>
        <input type="text" name="username" required autofocus>

        <label>كلمة المرور</label>
        <input type="password" name="password" required>

        <button type="submit">دخول</button>
    </form>

    <p class="muted">ليس لديك حساب؟ <a href="register.php">إنشاء حساب</a></p>
</section>
<?php include 'includes/footer.php'; ?>
