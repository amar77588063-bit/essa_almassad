<?php
if (!isset($pageTitle)) $pageTitle = 'Cyber Incident System';
$user = $_SESSION['user'] ?? null;
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="topbar">
    <a class="brand" href="dashboard.php">Cyber Incident System</a>
    <?php if ($user): ?>
        <nav>
            <a href="dashboard.php">لوحة التحكم</a>
            <a href="incidents.php"><?= is_employee() ? 'بلاغاتي' : 'الحوادث' ?></a>
            <a href="incident_add.php">إضافة حادث</a>
            <?php if (is_admin()): ?>
                <a href="users.php">إدارة المستخدمين</a>
            <?php endif; ?>
            <a href="profile.php">حسابي</a>
            <span class="role-badge"><?= e(role_label()) ?></span>
            <a href="logout.php">خروج</a>
        </nav>
    <?php endif; ?>
</header>
<main class="container">
