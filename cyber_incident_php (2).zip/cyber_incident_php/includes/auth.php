<?php
require_once __DIR__ . '/../config.php';

function require_login(): void {
    if (empty($_SESSION['user'])) {
        header('Location: login.php');
        exit;
    }
}

function current_role(): string {
    return $_SESSION['user']['role'] ?? '';
}

function is_employee(): bool {
    return current_role() === 'EMPLOYEE';
}

function is_analyst(): bool {
    return current_role() === 'ANALYST';
}

function is_admin(): bool {
    return current_role() === 'ADMIN';
}

function require_admin(): void {
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        exit('ليس لديك صلاحية الوصول إلى هذه الصفحة.');
    }
}

function role_label(?string $role = null): string {
    $role = $role ?? current_role();
    return match ($role) {
        'ADMIN' => 'مسؤول النظام',
        'ANALYST' => 'محلل أمني',
        default => 'موظف',
    };
}

function can_view_incident(array $incident): bool {
    if (is_admin() || is_analyst()) {
        return true;
    }
    return (int)$incident['created_by'] === (int)($_SESSION['user']['id'] ?? 0);
}

function can_edit_incident(array $incident): bool {
    if (is_admin() || is_analyst()) {
        return true;
    }
    return is_employee()
        && (int)$incident['created_by'] === (int)($_SESSION['user']['id'] ?? 0)
        && ($incident['status'] ?? '') === 'OPEN';
}

function can_delete_incident(array $incident): bool {
    return is_admin();
}


function status_label(string $status): string {
    return match ($status) {
        'OPEN' => 'مفتوح',
        'INVESTIGATING' => 'قيد التحقيق',
        'RESOLVED' => 'تم الحل',
        'CLOSED' => 'مغلق',
        default => $status,
    };
}

function severity_label(string $severity): string {
    return match ($severity) {
        'LOW' => 'منخفض',
        'MEDIUM' => 'متوسط',
        'HIGH' => 'مرتفع',
        'CRITICAL' => 'حرج',
        default => $severity,
    };
}

function category_label(string $category): string {
    return match ($category) {
        'PHISHING' => 'تصيد إلكتروني',
        'MALWARE' => 'برمجيات خبيثة',
        'UNAUTHORIZED_ACCESS' => 'دخول غير مصرح',
        'DATA_LEAKAGE' => 'تسريب بيانات',
        'ACCOUNT_COMPROMISE' => 'اختراق حساب',
        'OTHER' => 'أخرى',
        default => $category,
    };
}
