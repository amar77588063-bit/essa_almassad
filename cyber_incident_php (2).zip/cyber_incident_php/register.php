<?php
require_once 'config.php';

if (!empty($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (strlen($username) < 3) {
        $error = 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'البريد الإلكتروني غير صالح.';
    } elseif (strlen($password) < 6) {
        $error = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.';
    } else {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)'
            );
            $stmt->execute([
                $username,
                $email,
                password_hash($password, PASSWORD_DEFAULT),
                'EMPLOYEE'
            ]);
            $success = 'تم إنشاء الحساب بنجاح. يمكنك تسجيل الدخول.';
        } catch (PDOException $e) {
            $error = 'اسم المستخدم أو البريد الإلكتروني مستخدم مسبقًا.';
        }
    }
}

$pageTitle = 'إنشاء حساب';
include 'includes/header.php';
?>
<section class="auth-card">
    <h1>إنشاء حساب</h1>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <label>اسم المستخدم</label>
        <input type="text" name="username" required>

        <label>البريد الإلكتروني</label>
        <input type="email" name="email" required>

        <label>كلمة المرور</label>
        <input type="password" name="password" required>

        <button type="submit">إنشاء الحساب</button>
    </form>

    <p class="muted">لديك حساب؟ <a href="login.php">تسجيل الدخول</a></p>
</section>
<?php include 'includes/footer.php'; ?>
