<?php
require_once 'includes/auth.php';
require_login();

$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';
$severity = $_GET['severity'] ?? '';

$sql = "
SELECT i.id, i.title, i.category, i.severity, i.status, i.created_at, i.created_by, u.username,
       (SELECT COUNT(*) FROM incidents seq WHERE seq.id <= i.id) AS display_no
FROM incidents i
JOIN users u ON u.id = i.created_by
WHERE 1=1
";
$params = [];

if (is_employee()) {
    $sql .= ' AND i.created_by = ?';
    $params[] = $_SESSION['user']['id'];
}

if ($q !== '') {
    $sql .= " AND (i.title LIKE ? OR i.description LIKE ?";
    $like = "%$q%";
    array_push($params, $like, $like);

    if (ctype_digit($q)) {
        $sql .= " OR (SELECT COUNT(*) FROM incidents seq WHERE seq.id <= i.id) = ?";
        $params[] = (int)$q;
    }

    $sql .= ")";
}

if (in_array($status, ['OPEN','INVESTIGATING','RESOLVED','CLOSED'], true)) {
    $sql .= ' AND i.status = ?';
    $params[] = $status;
}

if (in_array($severity, ['LOW','MEDIUM','HIGH','CRITICAL'], true)) {
    $sql .= ' AND i.severity = ?';
    $params[] = $severity;
}

$sql .= ' ORDER BY i.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$incidents = $stmt->fetchAll();

$pageTitle = is_employee() ? 'بلاغاتي' : 'الحوادث';
include 'includes/header.php';
?>
<div class="page-title">
    <div>
        <h1><?= is_employee() ? 'بلاغاتي الأمنية' : 'الحوادث الأمنية' ?></h1>
        <p><?= is_employee() ? 'يمكنك مشاهدة البلاغات التي أنشأتها أنت فقط.' : 'يمكنك مشاهدة جميع الحوادث في النظام.' ?></p>
    </div>
    <a class="btn" href="incident_add.php">+ إضافة حادث جديد</a>
</div>

<form class="filters card" method="get">
    <input type="text" name="q" placeholder="بحث بالعنوان أو الرقم" value="<?= e($q) ?>">
    <select name="severity">
        <option value="">كل درجات الخطورة</option>
        <?php foreach (['LOW'=>'منخفض','MEDIUM'=>'متوسط','HIGH'=>'مرتفع','CRITICAL'=>'حرج'] as $key=>$label): ?>
            <option value="<?= $key ?>" <?= $severity === $key ? 'selected' : '' ?>><?= $label ?></option>
        <?php endforeach; ?>
    </select>
    <select name="status">
        <option value="">كل الحالات</option>
        <?php foreach (['OPEN'=>'مفتوح','INVESTIGATING'=>'قيد التحقيق','RESOLVED'=>'تم الحل','CLOSED'=>'مغلق'] as $key=>$label): ?>
            <option value="<?= $key ?>" <?= $status === $key ? 'selected' : '' ?>><?= $label ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit">بحث / تصفية</button>
    <a class="btn secondary" href="incidents.php">إعادة ضبط</a>
</form>

<div class="card table-wrap">
    <table>
        <thead><tr><th>#</th><th>العنوان</th><th>التصنيف</th><th>الخطورة</th><th>الحالة</th><th>المبلّغ</th><th>إجراءات</th></tr></thead>
        <tbody>
        <?php foreach ($incidents as $item): ?>
            <tr>
                <td><?= (int)$item['display_no'] ?></td>
                <td><?= e($item['title']) ?></td>
                <td><?= e(category_label($item['category'])) ?></td>
                <td><?= e(severity_label($item['severity'])) ?></td>
                <td><?= e(status_label($item['status'])) ?></td>
                <td><?= e($item['username']) ?></td>
                <td class="actions">
                    <a href="incident_view.php?id=<?= (int)$item['id'] ?>">عرض</a>
                    <?php if (can_edit_incident($item)): ?>
                        <a href="incident_edit.php?id=<?= (int)$item['id'] ?>">تعديل</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$incidents): ?><tr><td colspan="7">لا توجد نتائج.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php include 'includes/footer.php'; ?>
